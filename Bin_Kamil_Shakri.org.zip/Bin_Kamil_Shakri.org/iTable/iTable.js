function iTable() {
  // Constructor stays empty
}

iTable.prototype.createTableEnv = function(tableID) {
  // table 
  this.itable = document.getElementById(tableID);
  this.itable.setAttribute('class', 'i_table');
  // table head
  this.itableHead = document.createElement('DIV');
  this.itableHead.setAttribute('class','i_table_head');
  
  this.itableHeadWrap = this.elementCreator('DIV','i_table_head_wrap',this.itableHead);
  
  this.itableTitle = this.elementCreator('DIV','tableTitle',this.itableHeadWrap);

  this.searchInput = this.elementCreator('input','',this.itableHeadWrap);
  this.searchInput.name = 'searchinput';
  this.searchInput.type = 'text';
  this.searchInput.placeholder = 'Search';
  
  this.itable.insertAdjacentElement('beforebegin',this.itableHead);

  // table foot
  this.itableFoot = document.createElement('DIV');

  this.itableFoot.setAttribute('class','i_table_foot');
  this.itableFootWrap = this.elementCreator('DIV','i_table_head_wrap',this.itableFoot);

  this.rowsIndicator = this.elementCreator('DIV','rowsmeter',this.itableFootWrap);
  this.rowsSelection = this.elementCreator('DIV','selectionforrow',this.rowsIndicator);
  
  this.selectLable = this.elementCreator('label','',this.rowsSelection);
  this.selectLable.innerHTML = "Rows: ";
  
  this.selectionTag = this.elementCreator('Select','',this.selectLable);
  this.selectionTag.innerHTML = '<option value="5">5</option><option value="10" selected>10</option><option value="30">30</option><option value="50">50</option><option value="100">100</option>';
  
  this.pageNumber = this.elementCreator('DIV','pagenober',this.rowsIndicator);
  this.pageNumber.innerHTML = "1-10 of 11";
  
  this.pagination = this.elementCreator('DIV', 'paginationBTNss', this.itableFootWrap);
  this.preBtn = this.elementCreator('BUTTON', 'paginationLink', this.pagination);
  this.preBtn.innerHTML = "&lsaquo;";
  this.postBtn = this.elementCreator('BUTTON', 'paginationLink', this.pagination);
  this.postBtn.innerHTML = "&rsaquo;";

  this.itable.insertAdjacentElement('afterend',this.itableFoot);
};

// adding New UI to table
iTable.prototype.iTableExp = function(tableID) {
  var self = this;
  this.createTableEnv(tableID);
  var theadtag = this.itable.getElementsByTagName('thead')[0];
  var tfootrows = '<tfoot>' + theadtag.innerHTML + '</tfoot>';
  this.itable.insertAdjacentHTML('beforeend',tfootrows);
  
  var headtr = theadtag.getElementsByTagName('tr');
  var tableCaption = this.itable.getElementsByTagName('caption')[0];
  var tbodytag = this.itable.getElementsByTagName('tbody')[0];
  var bodytr = tbodytag.getElementsByTagName('tr');

  var pages, min_rows = 10, currentpagetab = 1;

  if(tableCaption){
    tableCaption.style.display = 'none';
    this.itableTitle.innerHTML = tableCaption.innerHTML;
  }
  else {
    this.itableTitle.innerHTML = document.title;
  }
  pages = this.pagefinder(min_rows, bodytr.length);
  
  this.itabShower(currentpagetab,pages,min_rows,bodytr,tbodytag);

  for(var i = 0; i < headtr.length; i++){
    var th = headtr[i].getElementsByTagName('TH');
    for(var j = 0; j < th.length; j++){
      th[j].innerHTML += '<span class="i_th_arrow">&#x25b4</span><span class="i_th_arrow">&#x25be</span>';
      // Store column index properly for closure context
      (function(colIndex) {
        th[colIndex].addEventListener('click', function(){
          self.sortTable(colIndex, headtr, currentpagetab, pages, min_rows, bodytr, tbodytag);
        });
      })(j);
    }
  }

  this.selectionTag.addEventListener('change', function(){
    min_rows = self.selectionTag.value;
    pages = self.pagefinder(min_rows, bodytr.length);
    self.itabShower(currentpagetab, pages, min_rows, bodytr, tbodytag);
  });
  
  this.preBtn.addEventListener('click', function(){
    currentpagetab += -1;
    self.itabShower(currentpagetab, pages, min_rows, bodytr, tbodytag);
  });

  this.postBtn.addEventListener('click', function(){
    currentpagetab += 1;
    self.itabShower(currentpagetab, pages, min_rows, bodytr, tbodytag);
  });

  this.searchInput.addEventListener('keyup', function(){
    self.tableFilter(currentpagetab, pages, min_rows, bodytr, tbodytag);
  });
};

iTable.prototype.itabShower = function(currentpage, pages, rowsperpage, bodytr, tbody) {
  if(bodytr.length == 0){
    tbody.insertAdjacentHTML('beforebegin','<div class="whenNoRow">No Items!</div>');
  }
  else {
    if(pages == 1){
      this.pagination.style.display = 'none';                
    }
    else{
      this.pagination.style.display = '';
    }

    if(currentpage <= 1){
      this.preBtn.disabled = true;
      this.postBtn.disabled = false;
    }
    
    if(currentpage >= pages){
      this.preBtn.disabled = false;
      this.postBtn.disabled = true;
    }

    if(currentpage > 1 && currentpage < pages){
      this.preBtn.disabled = false;
      this.postBtn.disabled = false;
    }

    if(currentpage > pages){
      currentpage = 1;
    }

    if(currentpage < 1){
      currentpage = pages;
    }
    this.itabDisplayer(currentpage, rowsperpage, bodytr);
  }
};

iTable.prototype.itabDisplayer = function(currentpage, irowsperpage, rows) {
  var start, end, s, e;
  end = irowsperpage * currentpage;
  start = end - irowsperpage;

  for(var k = 0; k < rows.length; k++){
    if(k >= start && k < end){
      rows[k].classList.remove("hidden");
    } else {
      rows[k].classList.add("hidden");
    }
  }

  s = this.updatetexture(start);
  if(end > rows.length){
    e = this.updatetexture(rows.length);
  }
  else {
    e = this.updatetexture(end);
  }
  this.pageNumber.innerHTML = s + "-"+ e + " of " + rows.length; 
};

iTable.prototype.updatetexture = function(i) {
  if(i < 10){
    i = "0" + i;
  }
  return i;
};

iTable.prototype.pagefinder = function(min_rows_to_show, tab_len) {
  var frameindex, r;
  r = tab_len % min_rows_to_show;
  if(min_rows_to_show > tab_len){
    return 1;
  }
  else {
    if(r == 0){
      frameindex = parseInt(tab_len / min_rows_to_show);
      return frameindex;
    }
    else {
      frameindex = parseInt(tab_len / min_rows_to_show) + 1;
      return frameindex;
    }
  }
};

iTable.prototype.tableFilter = function(currentpage, pages, rowsperpage, bodytr, tbody) {
  var filter, td, i, j, txtValue;
  filter = this.searchInput.value.toLowerCase();
  for(i = 0; i < bodytr.length; i++){
    bodytr[i].classList.add("hidden");
    for(j = 0; j < bodytr[i].getElementsByTagName('td').length; j++){
      td = bodytr[i].getElementsByTagName('td')[j];
      if(td){
        txtValue = td.textContent || td.innerText;
        if(txtValue.toLowerCase().indexOf(filter) > -1){
          bodytr[i].classList.remove("hidden");
          break;
        }
      }
    }
  }

  if(filter === ""){
    this.itabShower(currentpage, pages, rowsperpage, bodytr, tbody);
  }
};

iTable.prototype.sortTable = function(column, headtr, currentpage, pages, rowsperpage, bodytr, tbody) {
  var switching, i, j, x, y, shouldSwitch, dir, switchcount = 0;
  switching = true;
  dir = 'asc';

  while(switching){
    switching = false;

    for(i = 0; i < (bodytr.length - 1); i++){
      shouldSwitch = false;
      x = bodytr[i].getElementsByTagName('TD')[column];
      y = bodytr[i+1].getElementsByTagName('TD')[column];

      if(dir == 'asc'){
        if(x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()){
          shouldSwitch = true;
          break;
        }
      }
      else if(dir == 'desc'){
        if(x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()){
          shouldSwitch = true;
          break;
        }
      }
    }

    if(shouldSwitch){
      bodytr[i].parentNode.insertBefore(bodytr[i+1], bodytr[i]);
      switching = true;
      switchcount++;
    } else {
      if(switchcount == 0 && dir == 'asc'){
        dir = 'desc';
        switching = true;
      }
    }
  }

  for(i = 0; i < headtr.length; i++){
    var thhs = headtr[i].getElementsByTagName('TH');
    for(j = 0; j < thhs.length; j++){
      thhs[j].getElementsByTagName('span')[0].style.display = 'none';
      thhs[j].getElementsByTagName('span')[1].style.display = 'none';    
    }
  }

  if(dir == 'asc'){
    headtr[0].getElementsByTagName('th')[column].getElementsByTagName('span')[0].style.display = 'none';
    headtr[0].getElementsByTagName('th')[column].getElementsByTagName('span')[1].style.display = 'block';
  }
  else if(dir == 'desc'){
    headtr[0].getElementsByTagName('th')[column].getElementsByTagName('span')[1].style.display = 'none';
    headtr[0].getElementsByTagName('th')[column].getElementsByTagName('span')[0].style.display = 'block';
  }
  this.itabShower(currentpage, pages, rowsperpage, bodytr, tbody);
};

iTable.prototype.elementCreator = function(tagType, addClass, appendPlace) {
  var tagi = document.createElement(tagType);
  tagi.className = addClass;
  appendPlace.appendChild(tagi);
  return tagi;
};

iTable.prototype.elementRemover = function(tagtype, appendPlace) {
  appendPlace.removeChild(tagtype);
};