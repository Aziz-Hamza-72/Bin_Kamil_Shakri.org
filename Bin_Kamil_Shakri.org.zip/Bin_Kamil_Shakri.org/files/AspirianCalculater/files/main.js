var myVar;

function myLoader() {
    myVar = setTimeout(showPage, 1000);
}

function showPage() {
    document.getElementById("loader").style.display = "none";
    document.getElementById("Mydiv").style.display = "block";
}

function MyBtn() {
    window.open("files/main.html", "_self");
}