// this file is for script of the time html page for animating the page.
var onOffBtn = document.getElementById("onOffBtn");
var myMod = document.getElementById("modalFeed");
var myMod1 = document.getElementById("modalFeed1");
var closeBut1 = document.getElementById("modBtn1");
var closeBut = document.getElementById("modBtn");
//    for the middle displayloader of the watch
var displayLoader = document.getElementById("displayLoader");
var ScreenLed1 = document.getElementById("ScreenLed1");
var ScreenLed2 = document.getElementById("ScreenLed2");
var front1 = document.getElementById("front_window1");
var front2 = document.getElementById("front_window2");
var ONFBtn = "OffHa";
var AboutBtn = document.getElementById("AbkBtn");
var actualDisplay1 = document.getElementById("actualDisplay1");
var actualDisplay2 = document.getElementById("actualDisplay2");
var SWMAKER;
var startStopBtn = document.getElementById("startStopBtn");
var playBtn = document.getElementById("playBtn");
var pauseBtn = document.getElementById("pauseBtn");
var SW_Btn = "stopped";
var resetBtn = document.getElementById("resetBtn");
mytime();

// for onOffBtn of the watch
onOffBtn.onclick = function() {
    if (ONFBtn == "OffHa") {
        ontime();
        ONFBtn = "OnHa";
    } else {
        closer();
        resetSW();
        ONFBtn = "OffHa";
    }
}



// function for the onoff pressing
function ontime() {
    onOffBtn.style.stroke = "rgba(255,0,118,0.8)";
    filler(displayLoader, "rgba(255,0,118,0.8)");
    filler(ScreenLed1, "url(#LEDBlink1)");
    filler(ScreenLed2, "url(#LEDBlink1)");
    openCloseE(front1, "block");
    openCloseE(front2, "block");
    setTimeout(ontimein, 3000);
}
//func for the ontimein
function ontimein() {
    onOffBtn.style.stroke = "url(#controlBtns2)";
    filler(displayLoader, "rgba(74,222,252,0.9)");
    filler(ScreenLed1, "url(#LEDBlink2)");
    filler(ScreenLed2, "url(#LEDBlink2)");
    openCloseE(front1, "none");
    openCloseE(front2, "none");
    openCloseE(actualDisplay1, "block");
    openCloseE(actualDisplay2, "block");
}
// for closer btn
function closer() {
    onOffBtn.style.stroke = "none";
    filler(displayLoader, "none");
    filler(ScreenLed1, "gray");
    filler(ScreenLed2, "gray");
    openCloseE(front1, "none");
    openCloseE(front2, "none");
    openCloseE(actualDisplay1, "none");
    openCloseE(actualDisplay2, "none");

}
// About button
AboutBtn.onclick = function() {
    openCloseE(myMod, "block");
}
closeBut.onclick = function() {
    openCloseE(myMod, "none");
}
closeBut1.onclick = function() {
        openCloseE(myMod1, "none");
    }
    // for the timer of the watch
function mytime() {
    var bkhour = document.getElementById("bk-ho");
    var bkmin = document.getElementById("bk-min");
    var bksec = document.getElementById("bk-sec");
    var bkday = document.getElementById("bk-day");
    var bkmonth = document.getElementById("bk-mon");
    var bkdate = document.getElementById("bk-da");
    var bkyear = document.getElementById("bk-ye");
    var bkam = document.getElementById("bk-am");
    var bkpm = document.getElementById("bk-pm");
    var timer = new Date();
    var h = timer.getHours();
    var m = timer.getMinutes();
    var s = timer.getSeconds();
    var section = (h >= 12) ? (section = "PM") : (section = "AM");
    h = (h > 12) ? (h = h - 12) : (h);
    bkam = (section == "AM") ? (bkam.style.display = 'block') : (bkam.style.display = 'none');
    bkpm = (section == "PM") ? (bkpm.style.display = 'block') : (bkpm.style.display = 'none');
    var hval = updateTimer(h);
    var mval = updateTimer(m);
    var sval = updateTimer(s);
    bkhour.innerHTML = hval.toString();
    bkmin.innerHTML = mval.toString();
    bksec.innerHTML = sval.toString();
    var myday = timer.getDay();
    mywatchdays(myday, bkday);
    var mymonth = timer.getMonth();
    mywatchmonth(mymonth, bkmonth);
    var mydate = timer.getDate();
    bkdate.innerHTML = updateTimer(mydate);
    bkyear.innerHTML = timer.getFullYear();
    setTimeout(mytime, 1000);
}
// for the stopwatch of the page
var bksHour = document.getElementById("bks-ho");
var bksMin = document.getElementById("bks-min");
var bksSec = document.getElementById("bks-sec");
var bksMilli = document.getElementById("bks-milli");
startStopBtn.onclick = function() {
    if (ONFBtn == "OffHa") {
        openCloseE(myMod1, "block");
    } else {
        stopWControl();
    }
}

function stopWControl() {
    if (SW_Btn == "stopped") {
        startSW();
        openCloseE(playBtn, "none");
        openCloseE(pauseBtn, "block");
        SW_Btn = "started";
    } else {
        stopSW();
        openCloseE(playBtn, "block");
        openCloseE(pauseBtn, "none");
        SW_Btn = "stopped";
    }
}
resetBtn.onclick = function() {
    if (ONFBtn == "OffHa") {
        openCloseE(myMod1, "block");
    } else {
        resetSW();
    }
}

var mh = 0;
var mmi = 0;
var mse = 0;
var mmil = 0;
var mmilVal = 0;
var mseVal = 0;
var mmiVal = 0;
var mhVal = 0;

function myStopWatch() {
    mmilVal = updateTimer(mmil);
    mseVal = updateTimer(mse);
    mmiVal = updateTimer(mmi);
    mhVal = updateTimer(mh);
    mmil = ++mmil;
    if (mmil === 100) {
        mmil = 0;
        mse = ++mse;
    }
    if (mse === 60) {
        mse = 0;
        mmi = ++mmi;
    }
    if (mmi === 60) {
        mmi = 0;
        mh = ++mh;
    }

    bksHour.innerHTML = mhVal.toString();
    bksMin.innerHTML = mmiVal.toString();
    bksSec.innerHTML = mseVal.toString();
    bksMilli.innerHTML = mmilVal.toString();
}

function startSW() {
    SWMAKER = setInterval(myStopWatch, 10);
}

function stopSW() {
    clearInterval(SWMAKER);
}

function resetSW() {
    stopSW();
    mh = 0;
    mmi = 0;
    mse = 0;
    mmil = 0;
    mmilVal = 0;
    mseVal = 0;
    mmiVal = 0;
    mhVal = 0;
    mmilVal = updateTimer(mmil);
    mseVal = updateTimer(mse);
    mmiVal = updateTimer(mmi);
    mhVal = updateTimer(mh);
    bksHour.innerHTML = mhVal.toString();
    bksMin.innerHTML = mmiVal.toString();
    bksSec.innerHTML = mseVal.toString();
    bksMilli.innerHTML = mmilVal.toString();
    openCloseE(playBtn, "block");
    openCloseE(pauseBtn, "none");
    SW_Btn = "stopped";
}
// for the helping the function 
// filler func for fill any thing
function filler(Var, Value) {
    Var.style.fill = Value;
}
//openCloseE func for display Element & hide
function openCloseE(Var, Value) {
    Var.style.display = Value;
}
// time updater that is used to make the time to visible with 0
function updateTimer(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}
// func for days
function mywatchdays(Var, dayName) {
    switch (Var) {
        case 0:
            dayName.innerHTML = "Sunday";
            break;
        case 1:
            dayName.innerHTML = "Monday";
            break;
        case 2:
            dayName.innerHTML = "Tuesday";
            break;
        case 3:
            dayName.innerHTML = "Wednesday";
            break;
        case 4:
            dayName.innerHTML = "Thursday";
            break;
        case 5:
            dayName.innerHTML = "Friday";
            break;
        case 6:
            dayName.innerHTML = "Saturday";
    }
    return dayName.innerHTML;
}
//func for the mywatchmonth
function mywatchmonth(Var, monthname) {
    switch (Var) {
        case 0:
            monthname.innerHTML = "January";
            break;
        case 1:
            monthname.innerHTML = "February";
            break;
        case 2:
            monthname.innerHTML = "March";
            break;
        case 3:
            monthname.innerHTML = "April";
            break;
        case 4:
            monthname.innerHTML = "May";
            break;
        case 5:
            monthname.innerHTML = "June";
            break;
        case 6:
            monthname.innerHTML = "July";
            break;
        case 7:
            monthname.innerHTML = "August";
            break;
        case 8:
            monthname.innerHTML = "September";
            break;
        case 9:
            monthname.innerHTML = "October";
            break;
        case 10:
            monthname.innerHTML = "November";
            break;
        case 11:
            monthname.innerHTML = "December";
    }
    return monthname.innerHTML;
}