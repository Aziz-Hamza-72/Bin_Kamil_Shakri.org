document.querySelector('#starter').onclick = function() {
    navigator.mediaDevices.getDisplayMedia().then(stream => {
        navigator.mediaDevices.getUserMedia({ audio: true }).then(audiostream => {
            stream.addTrack(audiostream.getAudioTracks()[0]);
            var vidstream = document.querySelector('#screendisplay');
            if ('srcObject' in vidstream) {
                vidstream.srcObject = stream;
            } else {
                vidstream.src = window.URL.createObjectURL(stream);
            }
            var start = document.querySelector('#recordbtn');
            var stop = document.querySelector('#stopbtn');
            var mediaRecorder = new MediaRecorder(stream);
            var chunks = [];
            start.addEventListener('click', (ev) => {
                mediaRecorder.start();
                startSW();
            })
            stop.addEventListener('click', (ev) => {
                mediaRecorder.stop();
                stopSW();
            })
            mediaRecorder.ondataavailable = (ev) => {
                chunks.push(ev.data);
            }
            var blob;
            var vidURL;
            mediaRecorder.onstop = function(ev) {
                var viddownloaded = document.querySelector('#downloadedvideo');
                blob = new Blob(chunks, { 'type': 'video/webm;' });
                vidURL = window.URL.createObjectURL(blob);
                viddownloaded.src = vidURL;
                document.querySelector('#vidModel').style.display = 'block';
                resetSW();

            }
            document.querySelector('#downloadbtn').onclick = function() {
                var vidname = document.querySelector('#videoname').value;
                var eleme = document.createElement('a');
                eleme.style.display = 'none';
                eleme.download = vidname + ".webm";
                eleme.href = vidURL;
                document.body.appendChild(eleme);
                console.log(eleme);
                eleme.click();
                document.body.removeChild(eleme);
            }
        });
    });
}
document.querySelector('#cancelbtn').onclick = function() {
        document.querySelector('#vidModel').style.display = 'none';
    }
    // for the timering
var SWMAKER;
var bksHour = document.querySelector('#hour');
var bksMin = document.querySelector('#minute');
var bksSec = document.querySelector('#second');
var mh = 0;
var mmi = 0;
var mse = 0;
var mmil = 0;
var mmilVal = 0;
var mseVal = 0;
var mmiVal = 0;
var mhVal = 0;

function myStopWatch() {
    mmilVal = updateTimer(mmil);
    mseVal = updateTimer(mse);
    mmiVal = updateTimer(mmi);
    mhVal = updateTimer(mh);
    mmil = ++mmil;
    if (mmil === 100) {
        mmil = 0;
        mse = ++mse;
    }
    if (mse === 60) {
        mse = 0;
        mmi = ++mmi;
    }
    if (mmi === 60) {
        mmi = 0;
        mh = ++mh;
    }

    bksHour.innerHTML = mhVal.toString();
    bksMin.innerHTML = mmiVal.toString();
    bksSec.innerHTML = mseVal.toString();
}

function startSW() {
    SWMAKER = setInterval(myStopWatch, 10);
}

function stopSW() {
    clearInterval(SWMAKER);
}

function resetSW() {
    stopSW();
    mh = 0;
    mmi = 0;
    mse = 0;
    mmil = 0;
    mmilVal = 0;
    mseVal = 0;
    mmiVal = 0;
    mhVal = 0;
    mmilVal = updateTimer(mmil);
    mseVal = updateTimer(mse);
    mmiVal = updateTimer(mmi);
    mhVal = updateTimer(mh);
    bksHour.innerHTML = mhVal.toString();
    bksMin.innerHTML = mmiVal.toString();
    bksSec.innerHTML = mseVal.toString();
}

function updateTimer(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}